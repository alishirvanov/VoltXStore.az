
export default function Home() {
  return (
    <div style={{textAlign: "center", marginTop: "50px"}}>
      <h1>Welcome to VoltXStore!</h1>
      <p>This is a demo tech e-commerce landing page.</p>
    </div>
  );
}
